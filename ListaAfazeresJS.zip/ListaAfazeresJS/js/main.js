document.addEventListener("DOMContentLoaded",function(){

    let botaoAdicionar = document.getElementById("adicionar");
    let campoAfazeres = document.getElementById("campo-afazeres");
    let campoInput = document.getElementById("campo-input");


    botaoAdicionar.addEventListener("click",function(){

        var paragrafo = document.createElement("p"); //criando o elemento paragrafo no html

        paragrafo.classList.add("estilo-paragrafos");

        paragrafo.innerText = campoInput.value;

        campoAfazeres.appendChild(paragrafo); 
         //appendChild adiciona no final da lista um nó, isso fará com que o que o usuário digiotou apareça abaixo do input como tivesse sido adicionado

        campoInput.value = ""; //limpando o campo input quando adionar
       
       //criando a funçao para que quando a tarefa for realizada, um traço corte a palavra
        paragrafo.addEventListener("click",function(){
            paragrafo.style.textDecoration = "line-through";
        });

        //criando a funçao double click para remover a tarefa
        paragrafo.addEventListener("dblclick",function(){
            campoAfazeres.removeChild(paragrafo);
        });

        
    });

});